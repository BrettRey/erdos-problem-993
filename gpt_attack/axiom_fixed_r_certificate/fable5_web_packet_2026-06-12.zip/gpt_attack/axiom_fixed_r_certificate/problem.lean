import Mathlib.Tactic

/-!
  Axiom-style fixed-r certificate bridge targets.

  This file is intentionally outside the `Formal` Lean library.  It is a
  narrow proof-agent target.  Coefficient-perturbation lemmas use rational
  arithmetic; the finite-support mean-shift bridge is stated over `ℝ`, where
  the calculus API lives.
-/

namespace AxiomFixedR

open BigOperators

/--
Adjacent coefficient margins at a known unimodal mode imply a global margin.
The hypotheses `hleft_side` and `hright_side` encode the only part of
unimodality needed here.
-/
theorem global_margin_of_adjacent_margins
    (F : Nat -> Rat) (m : Nat) (eta : Rat)
    (hleft_margin : eta * F m <= F m - F (m - 1))
    (hright_margin : eta * F m <= F m - F (m + 1))
    (hleft_side : forall k, k < m -> F k <= F (m - 1))
    (hright_side : forall k, m < k -> F k <= F (m + 1)) :
    forall k, k ≠ m -> eta * F m <= F m - F k := by
  intro k hk
  by_cases hkm : k < m
  · have hk_le : F k <= F (m - 1) := hleft_side k hkm
    linarith
  · have hmk : m < k := Nat.lt_of_le_of_ne (Nat.le_of_not_gt hkm) (Ne.symm hk)
    have hk_le : F k <= F (m + 1) := hright_side k hmk
    linarith

/--
Conservative tie-fugacity perturbation bound.

This is the formal version of the hand proof in
`notes/fixed_r_fugacity_shift_sublemma_2026-05-21.md`.
-/
theorem fugacity_shift_bound
    (Fm Fprev Gm Gprev lam0 lam T : Rat)
    (hFm : 0 < Fm)
    (hGm_nonneg : 0 <= Gm)
    (hGprev_nonneg : 0 <= Gprev)
    (hT_nonneg : 0 <= T)
    (hT_half : T <= (1 / 2 : Rat))
    (hlam0_def : lam0 = Fprev / Fm)
    (hlam_def : lam = (Fprev + Gprev) / (Fm + Gm))
    (hlam0_low : (3 / 4 : Rat) <= lam0)
    (hlam0_high : lam0 <= 2)
    (hGm_bound : Gm <= T * Fm)
    (hGprev_bound : Gprev <= T * Fm) :
    |lam - lam0| <= 4 * T /\ (1 / 2 : Rat) <= lam := by
  have hFm_ne : Fm ≠ 0 := ne_of_gt hFm
  have hden_pos : 0 < Fm + Gm := by linarith
  have hden_ne : Fm + Gm ≠ 0 := ne_of_gt hden_pos
  have hlam0_nonneg : 0 <= lam0 := by linarith
  have hTF_nonneg : 0 <= T * Fm := by nlinarith
  have hFprev_eq : Fprev = lam0 * Fm := by
    rw [hlam0_def]
    field_simp [hFm_ne]
  have hFprev_lower : (3 / 4 : Rat) * Fm <= Fprev := by
    rw [hFprev_eq]
    nlinarith
  have hGm_half : Gm <= (1 / 2 : Rat) * Fm := by
    nlinarith
  have hden_upper : Fm + Gm <= (3 / 2 : Rat) * Fm := by
    nlinarith
  have hhalf_numer : (1 / 2 : Rat) * (Fm + Gm) <= Fprev + Gprev := by
    nlinarith
  have hlam_lower : (1 / 2 : Rat) <= lam := by
    rw [hlam_def]
    exact (le_div_iff₀ hden_pos).2 hhalf_numer

  have hdiff : lam - lam0 = (Gprev - lam0 * Gm) / (Fm + Gm) := by
    rw [hlam_def, hFprev_eq]
    field_simp [hden_ne]
    ring
  have h_lamG_bound : lam0 * Gm <= 2 * T * Fm := by
    have hmul := mul_le_mul hlam0_high hGm_bound hGm_nonneg (by norm_num : (0 : Rat) <= 2)
    nlinarith
  have hnum_upper : Gprev - lam0 * Gm <= 3 * T * Fm := by
    nlinarith
  have hnum_lower : -(3 * T * Fm) <= Gprev - lam0 * Gm := by
    nlinarith
  have hnum_abs : |Gprev - lam0 * Gm| <= 3 * T * Fm := by
    exact abs_le.mpr ⟨hnum_lower, hnum_upper⟩
  have habs_den : |Gprev - lam0 * Gm| <= 4 * T * (Fm + Gm) := by
    nlinarith
  have habs_shift : |(Gprev - lam0 * Gm) / (Fm + Gm)| <= 4 * T := by
    rw [abs_div, abs_of_pos hden_pos]
    exact (div_le_iff₀ hden_pos).2 habs_den
  constructor
  · rw [hdiff]
    exact habs_shift
  · exact hlam_lower

/-- Mean of a probability distribution supported on `{0, ..., N}`. -/
def finiteMean (N : Nat) (p : Fin (N + 1) -> ℝ) : ℝ :=
  ∑ k, p k * (k.val : ℝ)

/-- Second moment of a probability distribution supported on `{0, ..., N}`. -/
def finiteSecondMoment (N : Nat) (p : Fin (N + 1) -> ℝ) : ℝ :=
  ∑ k, p k * (k.val : ℝ) ^ 2

/-- Variance, written as a central second moment. -/
def finiteVariance (N : Nat) (p : Fin (N + 1) -> ℝ) : ℝ :=
  ∑ k, p k * ((k.val : ℝ) - finiteMean N p) ^ 2

theorem finiteVariance_nonneg
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_nonneg : ∀ k, 0 <= p k) :
    0 <= finiteVariance N p := by
  unfold finiteVariance
  exact Finset.sum_nonneg (by
    intro k _
    exact mul_nonneg (hp_nonneg k) (sq_nonneg _))

theorem finiteVariance_eq_second_sub_mean_sq
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_sum : (∑ k, p k) = 1) :
    finiteVariance N p = finiteSecondMoment N p - (finiteMean N p) ^ 2 := by
  set m : ℝ := finiteMean N p
  have hm : m = ∑ k, p k * (k.val : ℝ) := by
    simp [m, finiteMean]
  have hlinear : (∑ x, m * p x * (x.val : ℝ) * 2) = m ^ 2 * 2 := by
    calc
      (∑ x, m * p x * (x.val : ℝ) * 2)
          = m * (∑ x, p x * (x.val : ℝ)) * 2 := by
            rw [Finset.mul_sum, Finset.sum_mul]
            ring_nf
      _ = m ^ 2 * 2 := by
        rw [← hm]
        ring
  have hconst : (∑ x : Fin (N + 1), m ^ 2 * p x) = m ^ 2 := by
    calc
      (∑ x : Fin (N + 1), m ^ 2 * p x)
          = m ^ 2 * (∑ x : Fin (N + 1), p x) := by
            rw [Finset.mul_sum]
      _ = m ^ 2 := by
        rw [hp_sum]
        ring
  unfold finiteVariance finiteSecondMoment
  simp only [finiteMean]
  rw [← hm]
  ring_nf
  simp [Finset.sum_add_distrib, Finset.sum_neg_distrib]
  rw [show (∑ x : Fin (N + 1), p x * (x.val : ℝ) * m * 2) = m ^ 2 * 2 by
    calc
      (∑ x : Fin (N + 1), p x * (x.val : ℝ) * m * 2)
          = (∑ x : Fin (N + 1), m * p x * (x.val : ℝ) * 2) := by
            apply Finset.sum_congr rfl
            intro x _
            ring
      _ = m ^ 2 * 2 := hlinear]
  rw [show (∑ x : Fin (N + 1), p x * m ^ 2) = m ^ 2 by
    calc
      (∑ x : Fin (N + 1), p x * m ^ 2)
          = (∑ x : Fin (N + 1), m ^ 2 * p x) := by
            apply Finset.sum_congr rfl
            intro x _
            ring
      _ = m ^ 2 := hconst]
  ring

theorem finiteMean_nonneg
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_nonneg : ∀ k, 0 <= p k) :
    0 <= finiteMean N p := by
  unfold finiteMean
  exact Finset.sum_nonneg (by
    intro k _
    exact mul_nonneg (hp_nonneg k) (by exact_mod_cast k.val.zero_le))

theorem finiteMean_le_degree
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_nonneg : ∀ k, 0 <= p k)
    (hp_sum : (∑ k, p k) = 1) :
    finiteMean N p <= (N : ℝ) := by
  unfold finiteMean
  calc
    (∑ k, p k * (k.val : ℝ))
        <= ∑ k : Fin (N + 1), p k * (N : ℝ) := by
          apply Finset.sum_le_sum
          intro k _
          have hkN_nat : k.val <= N := Nat.le_of_lt_succ k.isLt
          have hkN : (k.val : ℝ) <= (N : ℝ) := by
            exact_mod_cast hkN_nat
          exact mul_le_mul_of_nonneg_left hkN (hp_nonneg k)
    _ = (N : ℝ) := by
      rw [← Finset.sum_mul, hp_sum]
      ring

theorem finiteSecondMoment_le_degree_mul_mean
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_nonneg : ∀ k, 0 <= p k) :
    finiteSecondMoment N p <= (N : ℝ) * finiteMean N p := by
  unfold finiteSecondMoment finiteMean
  calc
    (∑ k, p k * (k.val : ℝ) ^ 2)
        <= ∑ k : Fin (N + 1), p k * ((N : ℝ) * (k.val : ℝ)) := by
          apply Finset.sum_le_sum
          intro k _
          have hk_nonneg : 0 <= (k.val : ℝ) := by
            exact_mod_cast k.val.zero_le
          have hkN_nat : k.val <= N := Nat.le_of_lt_succ k.isLt
          have hkN : (k.val : ℝ) <= (N : ℝ) := by
            exact_mod_cast hkN_nat
          have hk_sq : (k.val : ℝ) ^ 2 <= (N : ℝ) * (k.val : ℝ) := by
            nlinarith
          exact mul_le_mul_of_nonneg_left hk_sq (hp_nonneg k)
    _ = (N : ℝ) * (∑ k, p k * (k.val : ℝ)) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro k _
      ring

/-- Popoviciu's variance bound for a distribution supported on `{0, ..., N}`. -/
theorem finiteVariance_le_degree_sq_div_four
    (N : Nat) (p : Fin (N + 1) -> ℝ)
    (hp_nonneg : ∀ k, 0 <= p k)
    (hp_sum : (∑ k, p k) = 1) :
    finiteVariance N p <= ((N : ℝ) ^ 2) / 4 := by
  have hvar_eq := finiteVariance_eq_second_sub_mean_sq N p hp_sum
  have hsecond := finiteSecondMoment_le_degree_mul_mean N p hp_nonneg
  have hm_nonneg := finiteMean_nonneg N p hp_nonneg
  have hm_le := finiteMean_le_degree N p hp_nonneg hp_sum
  rw [hvar_eq]
  calc
    finiteSecondMoment N p - (finiteMean N p) ^ 2
        <= (N : ℝ) * finiteMean N p - (finiteMean N p) ^ 2 := by
          linarith
    _ <= ((N : ℝ) ^ 2) / 4 := by
      nlinarith [sq_nonneg (finiteMean N p - (N : ℝ) / 2)]

theorem derivative_bound_from_gibbs_variance
    (N : Nat) (mu variance : ℝ -> ℝ) (t : ℝ)
    (ht : (1 / 2 : ℝ) <= t)
    (hvar_nonneg : 0 <= variance t)
    (hvar_le : variance t <= ((N : ℝ) ^ 2) / 4)
    (hderiv : deriv mu t = variance t / t) :
    |deriv mu t| <= ((N : ℝ) ^ 2) / 2 := by
  have ht_pos : 0 < t := by
    linarith
  rw [hderiv, abs_div, abs_of_nonneg hvar_nonneg, abs_of_pos ht_pos]
  exact (div_le_iff₀ ht_pos).2 (by nlinarith [sq_nonneg (N : ℝ)])

theorem abs_sub_le_of_deriv_bound_ordered
    (f : ℝ -> ℝ) (a b C : ℝ)
    (hab : a <= b)
    (hcont : ContinuousOn f (Set.Icc a b))
    (hdiff : DifferentiableOn ℝ f (Set.Ioo a b))
    (hderiv : ∀ x, x ∈ Set.Ioo a b -> |deriv f x| <= C) :
    |f b - f a| <= C * |b - a| := by
  by_cases h_eq : a = b
  · subst b
    simp
  · have hab_lt : a < b := lt_of_le_of_ne hab h_eq
    obtain ⟨c, hc_mem, hc_deriv⟩ := exists_deriv_eq_slope f hab_lt hcont hdiff
    have hb_sub_pos : 0 < b - a := by
      linarith
    have hdiff_eq : f b - f a = deriv f c * (b - a) := by
      rw [hc_deriv]
      field_simp [ne_of_gt hb_sub_pos]
    rw [hdiff_eq, abs_mul, abs_of_pos hb_sub_pos]
    exact mul_le_mul_of_nonneg_right (hderiv c hc_mem) (le_of_lt hb_sub_pos)

/--
Mean-shift bound from the Gibbs derivative identity and the finite-support
variance bound.  This replaces the old opaque Lipschitz-certificate target by
explicit proof obligations: continuity/differentiability of `mu`, the Gibbs
identity `deriv mu t = variance t / t`, and the variance bound on the interval.
-/
theorem mean_shift_bound_from_derivative_identity
    (N : Nat) (lam0 lam : ℝ) (mu variance : ℝ -> ℝ)
    (hlam0_low : (1 / 2 : ℝ) <= lam0)
    (hlam_low : (1 / 2 : ℝ) <= lam)
    (hcont : ContinuousOn mu (Set.uIcc lam0 lam))
    (hdiff : DifferentiableOn ℝ mu (Set.uIoo lam0 lam))
    (hvar_nonneg : ∀ t, t ∈ Set.uIoo lam0 lam -> 0 <= variance t)
    (hvar_le : ∀ t, t ∈ Set.uIoo lam0 lam -> variance t <= ((N : ℝ) ^ 2) / 4)
    (hderiv_id : ∀ t, t ∈ Set.uIoo lam0 lam -> deriv mu t = variance t / t) :
    |mu lam - mu lam0| <= (((N : ℝ) ^ 2) / 2) * |lam - lam0| := by
  by_cases horder : lam0 <= lam
  · have hcont' : ContinuousOn mu (Set.Icc lam0 lam) := by
      simpa [Set.uIcc, horder] using hcont
    have hdiff' : DifferentiableOn ℝ mu (Set.Ioo lam0 lam) := by
      simpa [Set.uIoo, horder] using hdiff
    exact abs_sub_le_of_deriv_bound_ordered mu lam0 lam (((N : ℝ) ^ 2) / 2) horder
      hcont' hdiff'
      (by
        intro t ht
        have ht_low : (1 / 2 : ℝ) <= t := by
          have hlt : lam0 < t := ht.1
          linarith
        exact derivative_bound_from_gibbs_variance N mu variance t ht_low
          (hvar_nonneg t (by simpa [Set.uIoo, horder] using ht))
          (hvar_le t (by simpa [Set.uIoo, horder] using ht))
          (hderiv_id t (by simpa [Set.uIoo, horder] using ht)))
  · have hrev : lam <= lam0 := le_of_not_ge horder
    have hcont' : ContinuousOn mu (Set.Icc lam lam0) := by
      simpa [Set.uIcc, hrev] using hcont
    have hdiff' : DifferentiableOn ℝ mu (Set.Ioo lam lam0) := by
      simpa [Set.uIoo, hrev] using hdiff
    have hbound :
        |mu lam0 - mu lam| <= (((N : ℝ) ^ 2) / 2) * |lam0 - lam| :=
      abs_sub_le_of_deriv_bound_ordered mu lam lam0 (((N : ℝ) ^ 2) / 2) hrev
        hcont' hdiff'
        (by
          intro t ht
          have ht_low : (1 / 2 : ℝ) <= t := by
            have hlt : lam < t := ht.1
            linarith
          exact derivative_bound_from_gibbs_variance N mu variance t ht_low
            (hvar_nonneg t (by simpa [Set.uIoo, hrev] using ht))
            (hvar_le t (by simpa [Set.uIoo, hrev] using ht))
            (hderiv_id t (by simpa [Set.uIoo, hrev] using ht)))
    simpa [abs_sub_comm] using hbound

/--
Mean-shift bound for a finite Gibbs distribution family.  The finite-support
probability hypotheses supply nonnegativity and Popoviciu's variance bound;
the only remaining analytic obligation is the standard Gibbs derivative
identity for the concrete mean function.
-/
theorem mean_shift_bound_from_finite_gibbs_distribution
    (N : Nat) (lam0 lam : ℝ) (mu : ℝ -> ℝ)
    (p : ℝ -> Fin (N + 1) -> ℝ)
    (hlam0_low : (1 / 2 : ℝ) <= lam0)
    (hlam_low : (1 / 2 : ℝ) <= lam)
    (hcont : ContinuousOn mu (Set.uIcc lam0 lam))
    (hdiff : DifferentiableOn ℝ mu (Set.uIoo lam0 lam))
    (hp_nonneg : ∀ t, t ∈ Set.uIoo lam0 lam -> ∀ k, 0 <= p t k)
    (hp_sum : ∀ t, t ∈ Set.uIoo lam0 lam -> (∑ k, p t k) = 1)
    (hderiv_id :
      ∀ t, t ∈ Set.uIoo lam0 lam -> deriv mu t = finiteVariance N (p t) / t) :
    |mu lam - mu lam0| <= (((N : ℝ) ^ 2) / 2) * |lam - lam0| := by
  exact mean_shift_bound_from_derivative_identity N lam0 lam mu
    (fun t => finiteVariance N (p t))
    hlam0_low hlam_low hcont hdiff
    (by
      intro t ht
      exact finiteVariance_nonneg N (p t) (hp_nonneg t ht))
    (by
      intro t ht
      exact finiteVariance_le_degree_sq_div_four N (p t) (hp_nonneg t ht) (hp_sum t ht))
    hderiv_id

end AxiomFixedR
